package com.example.firebase

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*


class ViewDataActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var dataTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_data)

        dataTextView = findViewById(R.id.dataTextView)

        // ✅ Firebase Database রেফারেন্স
        database = FirebaseDatabase.getInstance().getReference("users")

        // ✅ Firebase থেকে ডাটা পড়া
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val stringBuilder = StringBuilder()
                for (data in snapshot.children) {
                    val user = data.getValue(User::class.java)
                    stringBuilder.append("Name: ${user?.name}, Email: ${user?.email}\n")
                }
                dataTextView.text = stringBuilder.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                dataTextView.text = "Failed to load data"
            }
        })
    }

}
