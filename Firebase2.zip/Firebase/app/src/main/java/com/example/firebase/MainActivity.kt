package com.example.firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.example.firebase.ViewDataActivity

class MainActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameField = findViewById<EditText>(R.id.nameField)
        val emailField = findViewById<EditText>(R.id.emailField)
        val submitButton = findViewById<Button>(R.id.submitButton)
        val viewDataButton = findViewById<Button>(R.id.viewDataButton) // ✅ View Data Button

        // ✅ Firebase Database রেফারেন্স
        database = FirebaseDatabase.getInstance().getReference("users")

        submitButton.setOnClickListener {
            val name = nameField.text.toString()
            val email = emailField.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty()) {
                val userId = database.push().key!!
                val user = User(name, email)

                database.child(userId).setValue(user).addOnCompleteListener {
                    Toast.makeText(this, "Data Added Successfully!", Toast.LENGTH_SHORT).show()
                }.addOnFailureListener {
                    Toast.makeText(this, "Failed to Add Data", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // ✅ View Data Button: Click করলে ViewDataActivity খুলবে
        viewDataButton.setOnClickListener {
            val intent = Intent(this, ViewDataActivity::class.java)
            startActivity(intent)
        }
    }
}

data class User(val name: String, val email: String)
